# utttbot
A C++ [Ultimate Tic Tac Toe](https://playground.riddles.io/competitions/ultimate-tic-tac-toe) starter bot for the [riddles.io](https://www.riddles.io) platform.

Github repo:
https://github.com/afvanwoudenberg/utttbot