// main.cpp

#include "utttbot.h"

int main() {
	UTTTBot bot;
	bot.run();
	
	return 0;
}


